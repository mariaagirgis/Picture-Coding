function setup() {
  createCanvas(600, 600);
}
var back={
  r:255,
  g:231,
  b:18
  
}

var sun={
  posx:0,
  posy:0,
  speed:0
}

setInterval(movesun,200)

function movesun(){

  sun.posx=sun.posx+20
  sun.posy=sun.posy+20
  //back.r=back.r+10
  back.g=back.g-5
  //back.b=back.b+10
if(sun.posy>540){
  back.r=0
  back.g=0
  back.b=0
}

  
  
}
function draw() {
  background(back.r,back.g,back.b);
  text(mouseX+","+mouseY,20,20);
  fill("orange")
  ellipse(sun.posx, sun.posy, 100, 100)
  fill(54,138,35)
  rect(0,400,600,600)

}
  