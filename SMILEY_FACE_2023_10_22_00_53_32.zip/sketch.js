let pic1

function setup() {
  createCanvas(400, 400);
}
function preload(){
  pic1=loadImage("BACKGROUND.jpeg")
}

var smiley={
  eye
  
}

function draw() {
  background(220);
  image(pic1,0,0,400,400)
  text(mouseX+","+mouseY,20,20);
  fill("yellow")
  ellipse(197,184,200,200)
  ellipse()
}