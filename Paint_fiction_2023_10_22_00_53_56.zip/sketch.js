function setup() {
  createCanvas(400, 400);
}
var sun={
  xpos:200,
  ypos:200
  
  
}
function run(){
  fill("red")
  ellipse(sun.xpos,sun.ypos,100,100)
  triangle(165,162,193,68,228,158)
  triangle(228,157,310,125,250,198)
  triangle(250,197,320,234,231,237)
  triangle(148,196,129,203,150,210)
  rect(183,247,30)
}

function draw() {
  background(250,212,300);
  run()  
  sun.xpos=sun.xpos+
  sun.ypos=sun.ypos+
  text(mouseX+","+mouseY,20,20)
}