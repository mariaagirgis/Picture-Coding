function setup() {
  createCanvas(600, 600);
}

function draw() {
  strokeWeight(2)
  background(254,201,212);
  line(26,215,86,184)
  line(86,184,112,186)
  line(118,193,112,213)
  line(112,213,48,248)
  line(48,248,48,223)
  line(48,223,24,216)
  line(118,193,113,186)
  line(113,186,275,93)
  line(118,193,278,100)
  line(281,104,272,88)
  line(281,104,300,87)
  line(272,88,291,78)
  line(299,78,301,105)
  line(299,78,276,72)
  line(276,72,343,44)
  line(343,44,301,105)
  line(299,78,343,44)
  strokeWeight(5)
  line(0,350,400,120)
  line(0,163,281,0)
  
  
 
  text(mouseX+","+mouseY,20,20)
}