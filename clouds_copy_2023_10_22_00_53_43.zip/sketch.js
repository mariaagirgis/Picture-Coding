
let pic1
let pic2

var lane={
  xpos:275,
  ypos:300
}
setInterval(planemove,200)

function preload(){
  pic1=loadImage("CLOUD.png")
  pic2=loadImage("PLANE.png")
  
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(150,213,240);
  image(pic1,250,10,200,200)
  image(pic1,-75,100,200,200)
  image(pic2,lane.xpos,lane.ypos,300,175)
  text(mouseX+","+mouseY,20,20);
}
function planemove(){
  lane.xpos=lane.xpos-10
  lane.ypos=lane.ypos-10
}
  for(fly=0;fly<5;fly++){
    planemove()
  }
  

