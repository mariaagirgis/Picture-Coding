let pic1 
function setup() {
  createCanvas(600, 600);
}
var moon={
  xpos:500,
  ypos:475
}
  
var back={
  r:255,
  g:231,
  b:18
  
}

var sun={
  posx:0,
  posy:0,
  speed:0
}
function preload(){
  pic1=loadImage("MOON.png")
}
setInterval(movesun,50)

function movesun(){

  sun.posx=sun.posx+20
  sun.posy=sun.posy+20
  //back.r=back.r+10
  back.g=back.g-5
  //back.b=back.b+10

if(sun.posy>540){
  back.r=0
  back.g=0
  back.b=0
  movemoon()
}
}

function movemoon(){
if(moon.ypos>115){
  moon.ypos=moon.ypos-15
  }
}

//setInterval(movemoon,200)
  
var star={
  xrandom:600,
  yrandom:338
  
}
function makestar(){
  //for(star=0;star<23;star++){
  for(star.xrandom=0;star.xrandom<23;star.xrandom+1){
    fill("white")
    ellipse(600,338,5,5)
  }
  
}
function draw() {
  background(back.r,back.g,back.b);
  text(mouseX+","+mouseY,20,20);
  fill("orange")
  image(pic1,moon.xpos,moon.ypos,50,50)
  ellipse(sun.posx, sun.posy, 100, 100)
  fill(54,138,35)
  rect(0,400,600,600)
  //fill("white")

  //ellipse(88,68,5,5)
  makestar()
  
}
  