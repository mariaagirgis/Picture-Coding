
  function setup(){
  createCanvas(400, 400);
  }
  function draw(){
  strokeWeight(5)
  background(220);
  line(266,400,337,338)
  line(302,397,400,230)
  line(370,275,267,151)
  line(170,138,400,167)
  line(145,162,286,33)
  line(400,95,228,0)
  line(205,144,207,400)
  line(206,186,77,400)
  line(170,246,0,306)
  line(150,253,2,223)
  line(192,207,168,143)
  line(177,167,102,240)
  line(28,163,153,191)
  line(45,228,0,49)
  line(28,162,64,0)
  line(45,88,156,0)
  line(129,22,243,9)
  line(110,182,78,63)
  line(103,152,164,20)
  line(115,129,208,104)
  line(164,176,111,139)    
  text(mouseX+","+mouseY,20,20)

}
