
let pic1
let pic2

var lane={
  xpos:0,
  ypos:0
}
function preload(){
  pic1=loadImage("CLOUD.png")
  pic2=loadImage("PLANE.png")
  
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(150,213,240);
  image(pic1,250,10,200,200)
  image(pic1,-75,100,200,200)
  image(pic2,275,300,300,175)
  text(mouseX+","+mouseY,20,20);
  while(lane.xpos>200){
    planemove()
  }
function planemove(){
  lane.xpos=lane.xpos-15
  lane.ypos=lane.ypos-15
}
}