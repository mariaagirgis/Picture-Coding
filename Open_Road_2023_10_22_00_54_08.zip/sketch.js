function setup() {
  createCanvas(400, 400);
}

function draw() {
  strokeWeight(5)
  background(238,219,124);
  line(0,288,154,75)
  line(250,75,400,288)
  line(0,75,400,75)
  line(150,400,188,213)
  line(188,213,205,213)
  line(205,213,223,400)
  line(197,121,203,121)
  line(192,181,204,181)
  line(203,121,204,181)
  line(197,121,192,180)
  line(199,98,202,98)
  line(200,76,203,76)
  line(203,76,202,98)
  line(199,98,200,76)
 
  
  
  
  
  
  
  
  
   text(mouseX+","+mouseY,20,20)
}