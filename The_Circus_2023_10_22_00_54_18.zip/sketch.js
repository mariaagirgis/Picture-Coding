function setup() {
  createCanvas(400, 400);


}

  function draw() {
  background(24,54,134);
  fill(255,51,0)
  rect(250,350,34,55)
  rect(300,350,34,55)
  rect(100,350,34,55)
  
  fill(255,179,0)
  rect(50,350,34,55)
  rect(150,350,34,55)
  rect(220,350,34,55)
  
  fill(255,247,0)
  rect(280,350,34,55)
  rect(350,350,34,55)
  rect(340,350,34,55)
  
  fill(171,255,0)
  rect(330,350,34,55)
  rect(320,350,34,55)
  rect(350,350,34,55)
  
  fill(0,255,205)
  rect(370,350,34,55)
  rect(170,350,34,55)
  rect(180,350,34,55)
  rect(190,350,34,55)
  
  fill(0,51,255)
  rect(10,350,34,55)
  rect(15,350,34,55)
  rect(0,350,34,55)
  
  fill(154,0,255)
  rect(25,350,34,55)
  rect(40,350,34,55)
  rect(60,350,34,55)
  rect(70,350,34,55)
  
  fill(255,0,239)
  rect(300,350,34,55)
  rect(75,350,34,55)
  rect(120,350,34,55)
  
  fill(54,249,106)
  arc(350, 0, 80, 80, 0, PI + QUARTER_PI, PIE);
  arc(300, 0, 80, 80, 0, PI + QUARTER_PI, PIE);
  arc(200, 0, 80, 80, 0, PI + QUARTER_PI, PIE);
  fill(210,249,54)
  arc(250, 0, 80, 80, 0, PI + QUARTER_PI, PIE);
  arc(150, 0, 80, 80, 0, PI + QUARTER_PI, PIE);
  arc(100, 0, 80, 80, 0, PI + QUARTER_PI, PIE);
  fill(250,21,174)
  arc(50, 0, 80, 80, 0, PI + QUARTER_PI, PIE);
  arc(25, 0, 80, 80, 0, PI + QUARTER_PI, PIE);
  arc(360, 0, 80, 80, 0, PI + QUARTER_PI, PIE);
  fill(54,249,242)
  circle(200,200,100)
  
  fill(255,153,153)
  rect(0,200,200,10)
  rect(200,200,200,10)
}